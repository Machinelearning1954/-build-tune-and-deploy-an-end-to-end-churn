# Machine Learning Engineering Bootcamp - Capstone Project: Data Collection Rubric (Step 2)

**Learning Objective:** Collect the data for the project from the right source(s).

| Criteria                | Meets Expectations                                                                                                                                                           | Weightage |
|-------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------|
| **Time Estimate**       | 3-6 Hours                                                                                                                                                                    |           |
| **Completion**          | - Data and code are uploaded to Github (where applicable). <br> - For large datasets over 100MB, the student has used the Git Large File Extension, S3, or another appropriate way to integrate the data. | 2 points  |
| **Process and understanding** | - The submission shows that the student understands how to collect relevant data. <br> - The submission includes datasets that were well-chosen and relevant to the problem. <br> - The datasets chosen meet the minimum size requirements (i.e. at least 15K samples). | 6 points  |
| **Presentation**        | - Well-documented GitHub repository. <br> - Clear README.                                                                                                                          | 2 points  |


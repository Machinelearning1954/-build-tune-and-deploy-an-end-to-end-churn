import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Define file paths
DATA_DIR = "/home/ubuntu/telecom_churn_project/phase1_prototype/step2_data_collection/"
EDA_OUTPUT_DIR = "/home/ubuntu/telecom_churn_project/phase1_prototype/step5_data_wrangling/eda_outputs/"
PROCESSED_DATA_DIR = "/home/ubuntu/telecom_churn_project/phase1_prototype/step5_data_wrangling/processed_data/"

TRAIN_FILE = os.path.join(DATA_DIR, "churn-bigml-80.csv")
TEST_FILE = os.path.join(DATA_DIR, "churn-bigml-20.csv")

# Create output directories if they don't exist
os.makedirs(EDA_OUTPUT_DIR, exist_ok=True)
os.makedirs(PROCESSED_DATA_DIR, exist_ok=True)

# --- 1. Load Data ---
print("--- Loading Data ---")
try:
    df_train = pd.read_csv(TRAIN_FILE)
    df_test = pd.read_csv(TEST_FILE)
    print(f"Training data loaded. Shape: {df_train.shape}")
    print(f"Test data loaded. Shape: {df_test.shape}")
except FileNotFoundError as e:
    print(f"Error: {e}. Please ensure the data files are in the correct directory: {DATA_DIR}")
    print("As per the data collection report, these files were assumed to be manually placed due to download issues.")
    # For now, create dummy dataframes if files are not found to allow script to run further for structure check
    # In a real scenario, this would be a hard stop or a trigger to re-attempt download/placement.
    print("Creating dummy dataframes to proceed with script structure. THIS IS NOT THE ACTUAL DATA.")
    dummy_cols = ['State','Account length','Area code','International plan','Voice mail plan','Number vmail messages','Total day minutes','Total day calls','Total day charge','Total eve minutes','Total eve calls','Total eve charge','Total night minutes','Total night calls','Total night charge','Total intl minutes','Total intl calls','Total intl charge','Customer service calls','Churn']
    df_train = pd.DataFrame(np.random.randint(0,100,size=(5, 20)), columns=dummy_cols)
    df_train['Churn'] = np.random.choice([True, False], size=5)
    df_train['International plan'] = np.random.choice(['Yes', 'No'], size=5)
    df_train['Voice mail plan'] = np.random.choice(['Yes', 'No'], size=5)
    df_train['State'] = ['XX'] * 5
    df_test = pd.DataFrame(np.random.randint(0,100,size=(5, 20)), columns=dummy_cols)
    df_test['Churn'] = np.random.choice([True, False], size=5)
    df_test['International plan'] = np.random.choice(['Yes', 'No'], size=5)
    df_test['Voice mail plan'] = np.random.choice(['Yes', 'No'], size=5)
    df_test['State'] = ['YY'] * 5

print("\n--- Initial Inspection: Training Data ---")
print("First 5 rows:")
print(df_train.head())
print("\nInfo:")
df_train.info()
print("\nDescriptive Statistics:")
print(df_train.describe(include='all'))

print("\n--- Initial Inspection: Test Data ---")
print("First 5 rows:")
print(df_test.head())
print("\nInfo:")
df_test.info()
print("\nDescriptive Statistics:")
print(df_test.describe(include='all'))

# Combine for consistent preprocessing if necessary, but keep them separate for now for EDA
# df_full = pd.concat([df_train, df_test], ignore_index=True)
# print(f"\nCombined data shape: {df_full.shape}")

# --- 2. Handle Missing Values ---
print("\n--- Missing Value Analysis ---")
print("Missing values in training data:")
print(df_train.isnull().sum())
print("\nMissing values in test data:")
print(df_test.isnull().sum())

# Based on the provided sample, there are no missing values. If there were, strategies would be:
# For numerical: imputation with mean, median, or a constant (e.g., 0).
# For categorical: imputation with mode, or a new category like 'Missing'.
# Or, rows/columns could be dropped if missingness is extensive and imputation is not feasible.
# For this dataset, it seems clean in terms of missing values from the sample.

# --- 3. Data Type Conversions (if necessary) ---
print("\n--- Data Type Check and Conversion ---")
# 'Area code' is numerical but might be treated as categorical. For now, keep as is.
# 'Churn' is boolean, which is fine for target. Can be converted to int (0/1) later.
# 'International plan' and 'Voice mail plan' are Yes/No strings, need conversion to binary.

for df in [df_train, df_test]:
    df['International plan'] = df['International plan'].map({'Yes': 1, 'No': 0}).astype(int)
    df['Voice mail plan'] = df['Voice mail plan'].map({'Yes': 1, 'No': 0}).astype(int)
    df['Churn'] = df['Churn'].astype(int) # Convert boolean True/False to 1/0

print("Converted 'International plan', 'Voice mail plan' to binary and 'Churn' to int.")
print("\nTraining data types after conversion:")
print(df_train.dtypes)

# --- 4. Exploratory Data Analysis (EDA) ---
print("\n--- Exploratory Data Analysis (EDA) ---")

# Target variable distribution
plt.figure(figsize=(6, 4))
sns.countplot(x='Churn', data=df_train)
plt.title('Distribution of Churn in Training Data')
plt.savefig(os.path.join(EDA_OUTPUT_DIR, 'churn_distribution_train.png'))
plt.close()
print(f"Churn distribution plot saved to {EDA_OUTPUT_DIR}")
print("\nChurn Counts (Training Data):")
print(df_train['Churn'].value_counts(normalize=True))

# Numerical features distribution
numerical_cols = df_train.select_dtypes(include=np.number).columns.tolist()
numerical_cols.remove('Area code') # Treat as categorical for now
numerical_cols.remove('Churn') # Target variable
numerical_cols.remove('International plan') # Already binary
numerical_cols.remove('Voice mail plan') # Already binary

print(f"\nNumerical columns for distribution plots: {numerical_cols}")
for col in numerical_cols:
    plt.figure(figsize=(10, 4))
    sns.histplot(df_train[col], kde=True, label='Train')
    # sns.histplot(df_test[col], kde=True, label='Test', color='orange', alpha=0.7) # Optional: overlay test data
    plt.title(f'Distribution of {col}')
    plt.legend()
    plt.savefig(os.path.join(EDA_OUTPUT_DIR, f'hist_{col}.png'))
    plt.close()

    plt.figure(figsize=(10, 4))
    sns.boxplot(x='Churn', y=col, data=df_train)
    plt.title(f'{col} vs. Churn')
    plt.savefig(os.path.join(EDA_OUTPUT_DIR, f'boxplot_{col}_vs_churn.png'))
    plt.close()
print(f"Numerical feature distribution and box plots saved to {EDA_OUTPUT_DIR}")

# Categorical features distribution
categorical_cols = ['State', 'Area code', 'International plan', 'Voice mail plan'] # Re-include binary for churn relation
print(f"\nCategorical columns for count plots: {categorical_cols}")

for col in categorical_cols:
    plt.figure(figsize=(12, 5) if col == 'State' else (8,5))
    sns.countplot(x=col, hue='Churn', data=df_train, order = df_train[col].value_counts().index[:15] if col == 'State' else None)
    plt.title(f'{col} vs. Churn')
    if col == 'State':
        plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(os.path.join(EDA_OUTPUT_DIR, f'countplot_{col}_vs_churn.png'))
    plt.close()
print(f"Categorical feature count plots saved to {EDA_OUTPUT_DIR}")

# Correlation Matrix for numerical features
plt.figure(figsize=(12, 10))
# Select only numeric columns for correlation that make sense (excluding area code for now)
corr_cols = [col for col in numerical_cols if col not in ['Area code'] ] + ['International plan', 'Voice mail plan', 'Churn']
correlation_matrix = df_train[corr_cols].corr()
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm')
plt.title('Correlation Matrix of Numerical Features and Churn')
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_DIR, 'correlation_matrix.png'))
plt.close()
print(f"Correlation matrix heatmap saved to {EDA_OUTPUT_DIR}")

# --- 5. Feature Engineering (Initial Thoughts - more can be done later) ---
# Example: Total Mins, Total Calls, Total Charge (though charges are derived from mins)
# For now, we will proceed with existing features and handle categorical encoding next.

# --- 6. Categorical Feature Encoding ---
# 'State' and 'Area code' are categorical.
# 'State' has many unique values - consider target encoding, frequency encoding, or dropping if not predictive.
# For now, we'll use One-Hot Encoding for 'Area code' as it has few unique values.
# 'State' will be handled more carefully. For this initial pass, let's see its cardinality.
print(f"\nUnique values in 'State': {df_train['State'].nunique()}")
print(f"Unique values in 'Area code': {df_train['Area code'].nunique()}")

# One-hot encode 'Area code'
df_train = pd.get_dummies(df_train, columns=['Area code'], prefix='AreaCode')
df_test = pd.get_dummies(df_test, columns=['Area code'], prefix='AreaCode')
print("One-hot encoded 'Area code'.")

# For 'State', given high cardinality, we might drop it or use target encoding later.
# For this initial EDA/Wrangling script, we'll keep it and decide in the modeling phase or a more advanced feature engineering script.
# Let's drop 'State' for now to simplify the initial modeling pipeline. This decision can be revisited.
df_train = df_train.drop(columns=['State'])
df_test = df_test.drop(columns=['State'])
print("Dropped 'State' column for now. This can be revisited for more advanced encoding.")

# Align columns between train and test after one-hot encoding (in case some area codes are not in test)
common_cols = list(set(df_train.columns) & set(df_test.columns))
# Ensure 'Churn' is the last column for convenience if it's in common_cols
if 'Churn' in common_cols:
    target_col = 'Churn'
    common_cols.remove(target_col)
    df_train = df_train[common_cols + [target_col]]
    df_test = df_test[common_cols + [target_col]] # Test set also has Churn for evaluation
else: # Should not happen if data is prepared correctly
    df_train = df_train[common_cols]
    df_test = df_test[common_cols]

print("\nFinal Training Data Head after initial wrangling:")
print(df_train.head())
print(f"Training data shape: {df_train.shape}")

print("\nFinal Test Data Head after initial wrangling:")
print(df_test.head())
print(f"Test data shape: {df_test.shape}")

# --- 7. Save Processed Data (before scaling, which is model-dependent) ---
TRAIN_PROCESSED_FILE = os.path.join(PROCESSED_DATA_DIR, "train_processed.csv")
TEST_PROCESSED_FILE = os.path.join(PROCESSED_DATA_DIR, "test_processed.csv")

df_train.to_csv(TRAIN_PROCESSED_FILE, index=False)
df_test.to_csv(TEST_PROCESSED_FILE, index=False)
print(f"\nProcessed training data saved to {TRAIN_PROCESSED_FILE}")
print(f"Processed test data saved to {TEST_PROCESSED_FILE}")

print("\n--- Data Wrangling and Initial EDA Script Finished ---")


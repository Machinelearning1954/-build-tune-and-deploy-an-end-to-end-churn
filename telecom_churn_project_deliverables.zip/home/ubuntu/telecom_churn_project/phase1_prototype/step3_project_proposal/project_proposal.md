# Project Proposal: Telecom Customer Churn Prediction

## 1. Introduction and Problem Statement

**Problem:** Customer churn, the rate at which customers stop doing business with a company, is a critical challenge in the telecommunications industry. Acquiring new customers is often significantly more expensive than retaining existing ones. Therefore, accurately predicting which customers are likely to churn allows telecom companies to implement targeted retention strategies, thereby minimizing revenue loss and enhancing customer loyalty.

**Project Goal:** This project aims to develop a robust machine learning model to predict customer churn for a telecommunications provider. The model will identify customers at high risk of discontinuing their service, enabling proactive interventions.

## 2. Objectives

The primary objectives of this project are:

1.  **Data Acquisition and Preparation:** To collect, clean, and preprocess a relevant telecom customer dataset, making it suitable for machine learning modeling.
2.  **Exploratory Data Analysis (EDA):** To perform a thorough EDA to understand data characteristics, identify key features, and uncover patterns related to customer churn.
3.  **Model Development and Selection:** To build, train, and evaluate several machine learning models (e.g., Logistic Regression, Decision Trees, Random Forest, Gradient Boosting Machines) for churn prediction. The best-performing model will be selected based on appropriate evaluation metrics.
4.  **Performance Evaluation:** To rigorously evaluate the selected model's performance using metrics such as accuracy, precision, recall, F1-score, and AUC-ROC, ensuring it meets acceptable standards for practical application.
5.  **Prototype Deployment:** To develop a simple web application (using Flask) that serves the trained model via an API, allowing for predictions on new customer data through a basic user interface.
6.  **Documentation and Reporting:** To provide comprehensive documentation covering all project phases, including data sourcing, preprocessing, model development, evaluation, and deployment, along with a final project report and a well-documented GitHub repository.

## 3. Data Sources

*   **Primary Dataset:** The project will utilize the "Telecom Churn Dataset" from Kaggle, curated by Baligh Mnassri (`mnassrib/telecom-churn-datasets`). This dataset contains cleaned customer activity data and churn labels.
    *   Link: [https://www.kaggle.com/datasets/mnassrib/telecom-churn-datasets](https://www.kaggle.com/datasets/mnassrib/telecom-churn-datasets)
    *   Files: `churn-bigml-80.csv` (for training/validation) and `churn-bigml-20.csv` (for testing).
*   **Data Size Limitation:** As documented in the "Step 2: Data Collection Report," this dataset contains approximately 3,333 samples, which is below the 15,000 sample guideline in the course rubric. The project will proceed with this dataset, focusing on demonstrating the correct methodology, and this limitation will be clearly acknowledged in all reports. For the purpose of this project, it is assumed these files have been manually downloaded and are available locally at `/home/ubuntu/telecom_churn_project/phase1_prototype/step2_data_collection/`.

## 4. Proposed Methodology

The project will follow a standard machine learning workflow:

1.  **Data Collection:** (As described above, manual download assumed due to environment limitations).
2.  **Data Wrangling & EDA:**
    *   Load and inspect data using Pandas.
    *   Handle missing values (imputation or removal with justification).
    *   Perform data type conversions if necessary.
    *   Identify and handle outliers (if appropriate for the chosen models).
    *   Conduct EDA: univariate and bivariate analysis, visualizations (histograms, box plots, correlation matrices) to understand feature distributions and relationships with the target variable (Churn).
3.  **Feature Engineering & Preprocessing:**
    *   Convert categorical features into numerical representations (e.g., one-hot encoding, label encoding).
    *   Scale numerical features (e.g., StandardScaler, MinMaxScaler) to prevent features with larger magnitudes from dominating.
    *   Potentially create new features from existing ones if deemed beneficial (e.g., tenure in months to years, ratios of charges).
    *   Split the data into training and testing sets (using `churn-bigml-80.csv` for training/validation and `churn-bigml-20.csv` for final testing, or splitting the larger file if preferred).
4.  **Model Building & Training:**
    *   **Baseline Model:** Implement a simple baseline model (e.g., Logistic Regression) to establish a performance benchmark.
    *   **Advanced Models:** Train and evaluate several classification algorithms, including:
        *   Decision Trees
        *   Random Forest
        *   Gradient Boosting Machines (e.g., XGBoost, LightGBM, or Scikit-learn's GradientBoostingClassifier)
        *   Support Vector Machines (SVM)
    *   **Hyperparameter Tuning:** Utilize techniques like GridSearchCV or RandomizedSearchCV to find optimal hyperparameters for the selected models.
5.  **Model Evaluation:**
    *   Evaluate models on the test set using the following metrics:
        *   Accuracy
        *   Precision
        *   Recall (particularly important for churn prediction to identify as many actual churners as possible)
        *   F1-Score (harmonic mean of precision and recall)
        *   AUC-ROC (Area Under the Receiver Operating Characteristic Curve) to assess discriminative power.
    *   Compare model performances and select the best model based on a balance of these metrics and business objectives.
6.  **Deployment:**
    *   Save the trained model (e.g., using `joblib` or `pickle`).
    *   Develop a Flask web application with API endpoints to:
        *   Accept customer data as input (e.g., JSON payload).
        *   Load the trained model and make predictions.
        *   Return the churn prediction (e.g., probability and/or binary label).
    *   Create a simple HTML/CSS/JavaScript front-end to interact with the API.
    *   Containerize the application using Docker (optional, but good practice).
    *   Provide clear instructions for running the deployed application.

## 5. Evaluation Metrics

As mentioned above, the primary evaluation metrics will be:

*   **Accuracy:** Overall correctness of predictions.
*   **Precision (for Churn class):** Of those predicted to churn, how many actually churned? (TP / (TP + FP))
*   **Recall (Sensitivity for Churn class):** Of all actual churners, how many were correctly identified? (TP / (TP + FN)). This is often a key metric in churn prediction to minimize missed churners.
*   **F1-Score (for Churn class):** The harmonic mean of precision and recall, providing a balanced measure.
*   **AUC-ROC:** Measures the model's ability to distinguish between churners and non-churners across all thresholds.

The choice of the "best" model will prioritize recall and F1-score for the churn class, as failing to identify a churner (false negative) is typically more costly than incorrectly flagging a non-churner (false positive, though this also has costs associated with unnecessary retention efforts).

## 6. High-Level Timeline (Estimated)

This project will be completed in two main phases as per the capstone structure:

**Phase 1: Building a Working Prototype (Estimate: ~60 hours)**

*   **Week 1-2:**
    *   Initial Project Ideas & Scope Definition (Completed)
    *   Data Collection & Initial Exploration (Completed, with documented limitations)
    *   Project Proposal (This document)
    *   Survey Existing Research on Churn Prediction
*   **Week 3-4:**
    *   Detailed Data Wrangling and Cleaning
    *   In-depth Exploratory Data Analysis (EDA)
    *   Feature Engineering and Preprocessing
*   **Week 5-6:**
    *   Benchmark Model Implementation
    *   Initial training of various models
    *   GitHub Repository Setup and initial documentation for Phase 1

**Phase 2: Deploy to Production (Estimate: ~40 hours)**

*   **Week 7-8:**
    *   Advanced Model Experimentation and Hyperparameter Tuning
    *   Model Selection and Final Evaluation
    *   Refine code for clarity and efficiency (scaling considerations)
*   **Week 9-10:**
    *   Pick Deployment Method (Flask API confirmed)
    *   Design Deployment Solution (API endpoints, basic logging)
    *   Deployment Implementation (Flask app development, model serving)
*   **Week 11-12:**
    *   Develop Simple User Interface
    *   Testing of the deployed application
    *   Finalize GitHub repository, README, and all documentation
    *   Prepare for project sharing/presentation

## 7. Expected Deliverables

1.  **GitHub Repository:** A well-organized repository containing:
    *   All Python code (Jupyter notebooks for EDA/modeling, .py scripts for Flask app, utilities).
    *   Documentation files (this proposal, research survey, data wrangling report, final project report).
    *   Instructions for setting up the environment and running the project (README.md).
    *   (Link to/instructions for obtaining) the dataset.
2.  **Working Prototype:** A deployed (locally runnable) Flask application with a simple UI that allows users to get churn predictions.
3.  **Intermediate Submissions:** All documents as required by the capstone steps (e.g., Initial Ideas, Data Collection Report, this Proposal, Research Survey, etc.).
4.  **Final Project Report:** A comprehensive report detailing the entire project, from problem definition to deployment, including methodologies, results, challenges, and future work.

## 8. Potential Challenges and Mitigation

*   **Data Quality Issues:** The dataset might have hidden quality issues not apparent initially.
    *   **Mitigation:** Thorough EDA and data cleaning will be performed. If major issues arise, they will be documented, and their impact assessed.
*   **Model Performance:** Achieving high predictive performance can be challenging.
    *   **Mitigation:** Experiment with various algorithms, feature engineering techniques, and hyperparameter tuning. Clearly document performance and limitations.
*   **Deployment Complexity:** Setting up the Flask application and UI might present unforeseen technical hurdles.
    *   **Mitigation:** Start with a minimal viable product for deployment and iterate. Leverage online resources and documentation for Flask and related technologies.
*   **Dataset Size Limitation:** The dataset is smaller than the 15k guideline.
    *   **Mitigation:** This has been acknowledged. The focus will be on demonstrating robust methodology. If results are statistically insignificant due to size, this will be discussed. Techniques like cross-validation will be crucial.

This proposal outlines a comprehensive plan to tackle the telecom customer churn prediction problem, aligning with the course objectives and rubric requirements.

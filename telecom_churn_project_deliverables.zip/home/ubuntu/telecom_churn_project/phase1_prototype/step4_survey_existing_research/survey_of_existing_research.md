# Step 4: Survey of Existing Research - Telecom Customer Churn Prediction

## 1. Introduction

Customer churn prediction in the telecommunications industry is a well-researched area, given its significant financial implications. This survey reviews existing literature to identify common and effective machine learning techniques, algorithms, feature engineering strategies, data handling approaches (especially for imbalanced datasets), and model interpretability methods. The findings will inform the technical approach for this capstone project.

## 2. Common Machine Learning Algorithms

Research consistently shows that a variety of machine learning algorithms have been successfully applied to churn prediction. No single algorithm universally outperforms others, as performance often depends on the dataset characteristics and specific business context.

*   **Traditional Classification Algorithms:**
    *   **Logistic Regression:** Often used as a baseline model due to its simplicity, interpretability, and good performance on linearly separable data. (Ahmad et al., 2019; Sikri et al., 2024).
    *   **Decision Trees (e.g., C4.5, CART):** Valued for their ease of understanding and ability to capture non-linear relationships. However, they can be prone to overfitting. (Ahmad et al., 2019; Sikri et al., 2024).
    *   **Naive Bayes:** A probabilistic classifier that is simple and often performs well, especially with high-dimensional data, despite its strong independence assumptions. (Sikri et al., 2024).
    *   **K-Nearest Neighbors (KNN):** A non-parametric instance-based learning algorithm. Its performance can be sensitive to feature scaling and the choice of 'k'. (ScienceDirect article S2666720723001443; Sikri et al., 2024).
    *   **Support Vector Machines (SVM):** Effective in high-dimensional spaces and for non-linear classification using kernels, but can be computationally intensive for large datasets.

*   **Ensemble Methods:** These methods often yield superior performance by combining multiple models.
    *   **Random Forest (RF):** An ensemble of decision trees that reduces overfitting and improves generalization. It is frequently cited for high accuracy in churn prediction. (ScienceDirect article S2666720723001443; Ahmad et al., 2019).
    *   **Gradient Boosting Machines (GBM), including XGBoost, LightGBM:** These are powerful algorithms that build models sequentially, with each new model correcting errors made by previous ones. XGBoost is particularly highlighted for its performance and efficiency. (Ahmad et al., 2019; Sikri et al., 2024; Poudel et al., 2024). The study by Poudel et al. (2024) specifically found GBM to be superior with 81% accuracy.

*   **Deep Learning Techniques:**
    *   **Artificial Neural Networks (ANNs) / Multi-Layer Perceptrons (MLPs):** Capable of learning complex patterns, but require larger datasets and careful tuning. (Sikri et al., 2024).
    *   **Hybrid Deep Learning Models (e.g., BiLSTM-CNN):** Some recent research explores more complex architectures like combining Bidirectional LSTMs with CNNs, showing promising results (Nature article s41598-023-44396-w, though not directly browsed, its mention in search results is noted).

**Key Finding:** Ensemble methods, particularly Random Forest and Gradient Boosting variants (like XGBoost), are consistently reported as top performers in churn prediction tasks due to their robustness and ability to handle complex data relationships.

## 3. Feature Engineering and Selection

Effective feature engineering is crucial for building accurate churn models. Common categories of features include:

*   **Customer Demographics:** Age, gender, location (though often less predictive than behavioral data).
*   **Contractual Information:** Contract type (e.g., month-to-month, one-year, two-year), tenure, payment method, paperless billing.
*   **Service Usage Patterns:** Call details (number of calls, duration, international calls), data usage (internet service, online security, online backup, device protection, tech support, streaming TV, streaming movies), SMS usage.
*   **Billing and Payment History:** Monthly charges, total charges, payment delays, billing disputes.
*   **Customer Service Interactions:** Number of customer service calls, complaints lodged.
*   **Social Network Analysis (SNA) Features:** As highlighted by Ahmad et al. (2019), incorporating SNA features (e.g., degree centrality, network connectivity) can significantly enhance model performance by capturing the influence of a customer's social circle. Their study showed an AUC improvement from 84% to 93.3% with SNA features.

**Feature Selection:** Techniques like Recursive Feature Elimination (RFE), Principal Component Analysis (PCA), or using feature importance scores from tree-based models (e.g., Random Forest, XGBoost) are often employed to reduce dimensionality, improve model performance, and reduce overfitting.

## 4. Handling Imbalanced Data

Churn datasets are typically imbalanced, with a much smaller proportion of churners (minority class) compared to non-churners (majority class). This imbalance can bias models towards the majority class.

*   **Resampling Techniques:**
    *   **Over-sampling the minority class:** Techniques like SMOTE (Synthetic Minority Over-sampling Technique) create synthetic samples of the minority class. (Sikri et al., 2024, mention data resampling).
    *   **Under-sampling the majority class:** Randomly removing instances from the majority class. This can lead to loss of information.
    *   **Hybrid Approaches:** Combining over-sampling and under-sampling.
*   **Cost-Sensitive Learning:** Assigning different misclassification costs to different classes.
*   **Algorithmic Approaches:** Some algorithms (e.g., ensemble methods) can handle imbalanced data better or have built-in parameters to address it (e.g., `scale_pos_weight` in XGBoost).
*   **Novel Balancing Techniques:** Sikri et al. (2024) propose a "Ratio-based data balancing technique" which they claim outperforms traditional over-sampling and under-sampling methods.

**Key Finding:** Addressing class imbalance is critical. While traditional resampling methods are common, newer techniques and algorithmic adjustments are being explored. The choice of method can significantly impact model performance, particularly for the minority (churn) class.

## 5. Model Evaluation Metrics

Given the class imbalance, accuracy alone is not a sufficient metric.

*   **Common Metrics:**
    *   **Precision, Recall (Sensitivity), F1-Score:** Particularly important for the churn class. High recall is often prioritized to identify as many potential churners as possible.
    *   **Area Under the ROC Curve (AUC-ROC):** A good measure of the model's ability to discriminate between classes, robust to class imbalance. (Ahmad et al., 2019, used AUC).
    *   **Confusion Matrix:** To understand the types of errors (False Positives, False Negatives).

## 6. Model Interpretability

Understanding *why* a model predicts a customer will churn is crucial for targeted retention strategies.

*   **Explainable AI (XAI) Techniques:**
    *   **SHAP (SHapley Additive exPlanations):** Poudel et al. (2024) emphasize the use of SHAP for providing both local (individual prediction) and global (overall model behavior) explanations. SHAP values can highlight the contribution of each feature to a prediction.
    *   **LIME (Local Interpretable Model-agnostic Explanations):** Another popular technique for local explanations.
    *   **Feature Importance Plots:** Provided by tree-based models.

**Key Finding:** There is a growing emphasis on model interpretability in churn prediction to move beyond black-box models and provide actionable insights.

## 7. Implications for This Project

Based on this survey, the following will be considered for this capstone project:

1.  **Algorithm Selection:** Prioritize ensemble methods like Random Forest and XGBoost due to their consistently strong performance. Logistic Regression will be used as a baseline.
2.  **Feature Engineering:** Explore features related to customer demographics, contract details, service usage, billing, and customer service interactions. While SNA features are powerful, their implementation might be complex for this project's scope but will be noted as a potential enhancement.
3.  **Imbalanced Data Handling:** Employ techniques like SMOTE or investigate algorithmic solutions (e.g., class weighting in XGBoost) to address the expected class imbalance in the chosen dataset.
4.  **Evaluation:** Focus on AUC-ROC, Precision, Recall, and F1-Score for the churn class, in addition to overall accuracy.
5.  **Interpretability:** Utilize SHAP or feature importance plots from the chosen models to understand key churn drivers.
6.  **Dataset Size:** The literature often uses datasets of varying sizes. While the chosen dataset for this project is smaller than the rubric's ideal (15k samples), the focus will be on applying robust methodologies demonstrated in the literature.

## 8. References (Selected from browsed articles)

*   Ahmad, A. K., Jafar, A., & Aljoumaa, K. (2019). Customer churn prediction in telecom using machine learning in big data platform. *Journal of Big Data*, 6(1), 28. (Accessed via https://journalofbigdata.springeropen.com/articles/10.1186/s40537-019-0191-6)
*   Poudel, S. S., Pokharel, S., & Timilsina, M. (2024). Explaining customer churn prediction in telecom industry using tabular machine learning models. *Machine Learning with Applications*, 17, 100567. (Accessed via https://www.sciencedirect.com/science/article/pii/S2666827024000434)
*   Sikri, A., Jameel, R., Idrees, S. M., & Kaur, H. (2024). Enhancing customer retention in telecom industry with machine learning driven churn prediction. *Scientific Reports*, 14(1), 13097. (Accessed via https://www.nature.com/articles/s41598-024-63750-0)
*   Unnamed Authors. (2023). Customer churn prediction in telecom sector using machine learning techniques. *Results in Control and Optimization*, 12, 100288. (Accessed via https://www.sciencedirect.com/science/article/pii/S2666720723001443) *(Note: Authors for this specific ScienceDirect article were not immediately parsed by the browser tool, but the content was used)*

This survey provides a solid foundation for developing a methodologically sound and effective churn prediction model for the capstone project.

import pandas as pd
import numpy as np
import os
import joblib
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler # Should be loaded via joblib
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, make_scorer
# import xgboost as xgb # Consider adding if environment supports it easily, or stick to scikit-learn's GBM

# Define file paths
PROCESSED_DATA_DIR = "/home/ubuntu/telecom_churn_project/phase1_prototype/step5_data_wrangling/processed_data/"
BENCHMARK_MODEL_DIR = "/home/ubuntu/telecom_churn_project/phase1_prototype/step6_benchmark_model/"
ADVANCED_MODELS_DIR = "/home/ubuntu/telecom_churn_project/phase2_deploy_to_production/step7_experiment_with_models/"

TRAIN_PROCESSED_FILE = os.path.join(PROCESSED_DATA_DIR, "train_processed.csv")
TEST_PROCESSED_FILE = os.path.join(PROCESSED_DATA_DIR, "test_processed.csv")
SCALER_FILE = os.path.join(BENCHMARK_MODEL_DIR, "scaler_benchmark.joblib") # Use the same scaler

REPORT_FILE = os.path.join(ADVANCED_MODELS_DIR, "advanced_models_experiment_report.txt")
BEST_MODEL_FILE = os.path.join(ADVANCED_MODELS_DIR, "best_churn_model.joblib")

# Create output directory if it doesn't exist
os.makedirs(ADVANCED_MODELS_DIR, exist_ok=True)

# --- 1. Load Processed Data and Scaler ---
print("--- Loading Processed Data and Scaler ---")
try:
    df_train = pd.read_csv(TRAIN_PROCESSED_FILE)
    df_test = pd.read_csv(TEST_PROCESSED_FILE)
    scaler = joblib.load(SCALER_FILE)
    print(f"Processed training data loaded. Shape: {df_train.shape}")
    print(f"Processed test data loaded. Shape: {df_test.shape}")
    print("Scaler loaded.")
except FileNotFoundError as e:
    print(f"Error: {e}. Ensure processed data and scaler exist. Run previous steps.")
    # Create dummy dataframes if files are not found to allow script to run further for structure check
    print("Creating dummy dataframes and a dummy scaler to proceed. THIS IS NOT THE ACTUAL DATA/SCALER.")
    dummy_cols = [col for col in pd.read_csv("/home/ubuntu/telecom_churn_project/phase1_prototype/step2_data_collection/churn-bigml-80.csv").columns if col not in ["State", "Area code"] ] + ["AreaCode_408", "AreaCode_415", "AreaCode_510"]
    df_train = pd.DataFrame(np.random.rand(20, len(dummy_cols)), columns=dummy_cols) # Increased dummy sample size
    df_train["Churn"] = np.random.choice([0,1], size=20, p=[0.8,0.2]) # Make it a bit imbalanced
    df_test = pd.DataFrame(np.random.rand(10, len(dummy_cols)), columns=dummy_cols)
    df_test["Churn"] = np.random.choice([0,1], size=10, p=[0.7,0.3])
    scaler = StandardScaler() # Dummy scaler
    scaler.fit(df_train.drop("Churn", axis=1)) # Fit dummy scaler

# Separate features (X) and target (y)
X_train_raw = df_train.drop("Churn", axis=1)
y_train = df_train["Churn"]
X_test_raw = df_test.drop("Churn", axis=1)
y_test = df_test["Churn"]

# Apply scaling
X_train_scaled = scaler.transform(X_train_raw)
X_test_scaled = scaler.transform(X_test_raw)

print(f"X_train_scaled shape: {X_train_scaled.shape}, y_train shape: {y_train.shape}")
print(f"X_test_scaled shape: {X_test_scaled.shape}, y_test shape: {y_test.shape}")

# --- 2. Define Models and Hyperparameter Grids ---
print("\n--- Defining Models and Hyperparameter Grids ---")

# Using recall for the positive class (churn=1) as a key scorer for GridSearch
# because identifying churners is often more critical.
recall_scorer = make_scorer(recall_score, pos_label=1, zero_division=0)

models_params = {
    "DecisionTree": {
        "model": DecisionTreeClassifier(random_state=42, class_weight='balanced'),
        "params": {
            "max_depth": [3, 5, 7, 10],
            "min_samples_split": [2, 5, 10],
            "min_samples_leaf": [1, 2, 5]
        }
    },
    "RandomForest": {
        "model": RandomForestClassifier(random_state=42, class_weight='balanced'),
        "params": {
            "n_estimators": [50, 100, 150],
            "max_depth": [5, 10, None],
            "min_samples_split": [2, 5],
            "min_samples_leaf": [1, 2]
        }
    },
    "GradientBoosting": {
        "model": GradientBoostingClassifier(random_state=42),
        "params": {
            "n_estimators": [50, 100, 150],
            "learning_rate": [0.01, 0.1, 0.2],
            "max_depth": [3, 5]
        }
    }
    # "XGBoost": { # Uncomment if xgboost is available and configured
    #     "model": xgb.XGBClassifier(random_state=42, use_label_encoder=False, eval_metric='logloss', scale_pos_weight= (y_train.value_counts()[0]/y_train.value_counts()[1]) if y_train.value_counts()[1] > 0 else 1 ),
    #     "params": {
    #         "n_estimators": [50, 100],
    #         "learning_rate": [0.05, 0.1],
    #         "max_depth": [3, 5]
    #     }
    # }
}

results = {}
best_estimators = {}

report_content = "Advanced Models Experimentation Report\n"
report_content += "="*50 + "\n\n"

# --- 3. Train and Evaluate Models with GridSearchCV ---
if y_train.nunique() < 2:
    print("ERROR: Training data target has only one class. Cannot train classification models.")
    report_content += "ERROR: Training data target has only one class. Cannot train classification models.\n"
    report_content += "This occurred with the sample data. Full dataset is required for proper training.\n"
else:
    print("\n--- Training and Evaluating Models with GridSearchCV (Scoring: Recall for Churn) ---")
    for model_name, mp in models_params.items():
        print(f"\nTraining {model_name}...")
        report_content += f"\n--- {model_name} ---\n"
        try:
            grid_search = GridSearchCV(mp["model"], mp["params"], cv=3, scoring=recall_scorer, n_jobs=-1, error_score='raise') # cv=3 for small sample, increase for real data
            grid_search.fit(X_train_scaled, y_train)
            
            best_estimators[model_name] = grid_search.best_estimator_
            y_pred_test = grid_search.predict(X_test_scaled)
            y_pred_proba_test = grid_search.predict_proba(X_test_scaled)[:, 1] if hasattr(grid_search.best_estimator_, "predict_proba") else [0.5]*len(y_test) # Fallback for proba

            accuracy = accuracy_score(y_test, y_pred_test)
            precision = precision_score(y_test, y_pred_test, pos_label=1, zero_division=0)
            recall = recall_score(y_test, y_pred_test, pos_label=1, zero_division=0)
            f1 = f1_score(y_test, y_pred_test, pos_label=1, zero_division=0)
            auc = roc_auc_score(y_test, y_pred_proba_test)
            cm = confusion_matrix(y_test, y_pred_test)

            results[model_name] = {"Accuracy": accuracy, "Precision": precision, "Recall": recall, "F1-Score": f1, "AUC-ROC": auc, "ConfusionMatrix": cm, "BestParams": grid_search.best_params_}
            
            report_content += f"Best Parameters: {grid_search.best_params_}\n"
            report_content += f"Test Accuracy: {accuracy:.4f}\n"
            report_content += f"Test Precision (Churn=1): {precision:.4f}\n"
            report_content += f"Test Recall (Churn=1): {recall:.4f}\n"
            report_content += f"Test F1-Score (Churn=1): {f1:.4f}\n"
            report_content += f"Test AUC-ROC: {auc:.4f}\n"
            report_content += f"Test Confusion Matrix:\n{cm}\n"
            print(f"{model_name} evaluated. Recall (Churn=1): {recall:.4f}")

        except Exception as e:
            print(f"Error training/evaluating {model_name}: {e}")
            report_content += f"Error training/evaluating {model_name}: {e}\n"
            results[model_name] = {"Error": str(e)}

# --- 4. Select Best Model and Save ---
print("\n--- Selecting and Saving Best Model ---")
best_model_name = None
best_recall = -1 # Prioritizing recall for churn class

if results:
    for name, metrics in results.items():
        if "Recall" in metrics and metrics["Recall"] > best_recall:
            best_recall = metrics["Recall"]
            best_model_name = name
        elif "Recall" not in metrics and best_model_name is None: # Handle cases where only errors were stored
             best_model_name = name # Pick first one with error if all failed

if best_model_name and "Error" not in results[best_model_name]:
    final_best_model = best_estimators[best_model_name]
    joblib.dump(final_best_model, BEST_MODEL_FILE)
    report_content += f"\n--- Best Model Selected: {best_model_name} (based on Recall for Churn) ---\n"
    report_content += f"Recall: {results[best_model_name]['Recall']:.4f}\n"
    report_content += f"Model saved to: {BEST_MODEL_FILE}\n"
    print(f"Best model ({best_model_name}) saved to {BEST_MODEL_FILE}")
elif best_model_name:
    report_content += f"\n--- No model performed successfully. Best model ({best_model_name}) had error: {results[best_model_name]['Error']} ---\n"
    print(f"No model performed successfully. Best model ({best_model_name}) had error: {results[best_model_name]['Error']}")
else:
    report_content += "\n--- No models were successfully trained or evaluated. ---"
    print("No models were successfully trained or evaluated.")

# --- 5. Save Report ---
with open(REPORT_FILE, "w") as f:
    f.write(report_content)
print(f"\nAdvanced models experimentation report saved to {REPORT_FILE}")

print("\n--- Advanced Model Experimentation Script Finished ---")


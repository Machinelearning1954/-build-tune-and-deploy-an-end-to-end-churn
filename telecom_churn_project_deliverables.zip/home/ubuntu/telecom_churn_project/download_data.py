import kagglehub
import pandas as pd
import os

# Define the save path
save_dir = "/home/ubuntu/telecom_churn_project/phase1_prototype/step2_data_collection/"
os.makedirs(save_dir, exist_ok=True)

print(f"Attempting to download dataset to {save_dir} using kagglehub.dataset_download...")

# The dataset handle is "mnassrib/telecom-churn-datasets"
# The files we expect are "churn-bigml-80.csv" and "churn-bigml-20.csv"

try:
    # kagglehub.dataset_download will download files to the specified path.
    # For multi-file datasets, 'path' should be a directory.
    kagglehub.dataset_download("mnassrib/telecom-churn-datasets", path=save_dir)
    print(f"Dataset files should be downloaded to: {save_dir}")

    # Define expected file paths
    file_80_path = os.path.join(save_dir, "churn-bigml-80.csv")
    file_20_path = os.path.join(save_dir, "churn-bigml-20.csv")

    # Check if files exist and load them
    if os.path.exists(file_80_path):
        df_80 = pd.read_csv(file_80_path)
        print("\n--- churn-bigml-80.csv Info ---")
        print(f"Shape: {df_80.shape}")
        print(df_80.head())
        print(f"Successfully loaded {file_80_path}")
    else:
        print(f"ERROR: {file_80_path} not found after download attempt.")

    if os.path.exists(file_20_path):
        df_20 = pd.read_csv(file_20_path)
        print("\n--- churn-bigml-20.csv Info ---")
        print(f"Shape: {df_20.shape}")
        print(df_20.head())
        print(f"Successfully loaded {file_20_path}")
    else:
        print(f"ERROR: {file_20_path} not found after download attempt.")

    if os.path.exists(file_80_path) and os.path.exists(file_20_path):
        total_samples = df_80.shape[0] + df_20.shape[0]
        print(f"\nTotal samples in combined datasets: {total_samples}")
        if total_samples < 15000:
            print("NOTE: The total number of samples is less than the 15,000 mentioned in the rubric. This will be documented.")
    else:
        print("\nCould not calculate total samples as one or both files were not found.")
        print("Please check Kaggle API setup (e.g., ~/.kaggle/kaggle.json or KAGGLE_USERNAME/KAGGLE_KEY environment variables).")

except Exception as e:
    print(f"An error occurred during dataset download or processing: {e}")
    print("This might be due to missing Kaggle API credentials (kaggle.json or environment variables KAGGLE_USERNAME/KAGGLE_KEY) or other issues.")

print("Data download script finished.")

